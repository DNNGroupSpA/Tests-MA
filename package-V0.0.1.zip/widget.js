addWidget(function(scope,element,context){
  });